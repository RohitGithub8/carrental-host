<?php 
session_start();
include('includes/config.php');

// Database 

if (isset($_POST['send_otp'])) {
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];

    // Generate a random OTP (you can customize the length)
    $otp = mt_rand(100000, 999999);

    // Send the OTP to the user's email
    $subject = "OTP Verification for Password Reset";
    $message = "Your OTP is: $otp";
    $headers = "From: car2go.business.bmcc@gmail.com"; // Replace with your email address

    if (mail($email, $subject, $message, $headers)) {
        // Store the OTP and email in a session for verification
        $_SESSION['otp'] = $otp;
        $_SESSION['email'] = $email;

        // Update the user's OTP in the database
        $sql = "UPDATE `tblusers` SET `otp` = :otp WHERE `EmailId` = :email";
        $query = $dbh->prepare($sql);
        $query->bindParam(':otp', $otp, PDO::PARAM_INT);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->execute();

        echo "<script>alert('OTP sent to your email. Please check your email for the OTP.');</script>";
    } else {
        echo "<script>alert('Failed to send OTP. Please try again later.');</script>";
    }
}

if (isset($_POST['verify_otp'])) {
    // Check if the entered OTP matches the stored OTP
    $entered_otp = $_POST['entered_otp'];
    $stored_otp = $_SESSION['otp'];
    $email = $_SESSION['email'];

    if ($entered_otp == $stored_otp) {
        // OTP is valid, allow password change

        // Clear the OTP in the database
        $sql = "UPDATE `tblusers` SET `otp` = NULL WHERE `EmailId` = :email";
        $query = $dbh->prepare($sql);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->execute();

        // Update the password in the database
        $newpassword = md5($_POST['newpassword']);
        $sql = "UPDATE `tblusers` SET `Password` = :newpassword WHERE `EmailId` = :email";
        $query = $dbh->prepare($sql);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
        $query->execute();

        echo "<script>alert('Your password has been successfully changed.');</script>";
    } else {
        echo "<script>alert('Invalid OTP. Please enter the correct OTP.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Password Reset</title>
</head>
<body>
    <div class="modal fade" id="forgotpassword">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title">Password Recovery</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="forgotpassword_wrap">
                            <div class="col-md-12">
                                <form name="chngpwd" method="post">
                                    <div class="form-group">
                                        <input type="email" name="email" class="form-control" placeholder="Your Email address*" required="">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="mobile" class="form-control" placeholder="Your Reg. Mobile*" required="">
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" value="Send OTP" name="send_otp" class="btn btn-block">
                                    </div>
                                </form>
                               
                                <form name="otp_verification" method="post">
                                    <div class="form-group">
                                        <input type="text" name="entered_otp" class="form-control" placeholder="Enter OTP" required="">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="newpassword" class="form-control" placeholder="New Password*" required="">
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" value="Verify OTP and Change Password" name="verify_otp" class="btn btn-block">
                                    </div>
                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
