<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Car2Go | Page details</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
    <!-- Custom Style -->
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
    <link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
    <!-- Slick Slider CSS -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Bootstrap Slider CSS -->
    <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    
    <!-- Custom CSS for header and footer -->
    <style>
        /* Add your custom CSS for header and footer here */
    </style>

    <!-- Custom CSS for Privacy Policy Page -->
    <style>
        /* Professional styling for Privacy Policy */
        .privacy_policy {
            background-color: #f7f7f7;
            padding: 30px 0;
        }
        .privacy_policy h2 {
            font-size: 28px;
            margin-bottom: 20px;
        }
        .privacy_policy h3 {
            font-size: 20px;
            margin-top: 20px;
        }
        .privacy_policy p {
            font-size: 16px;
            line-height: 1.6;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <?php include('includes/header.php'); ?>

    <section class="page-header aboutus_page">
        <div class="container">
            <div class="page-header_wrap">
                <div class="page-heading">
                    <h1>Privacy Policy</h1>
                </div>
                <ul class="coustom-breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li>Privacy Policy</li>
                </ul>
            </div>
        </div>
        <!-- Dark Overlay -->
        <div class="dark-overlay"></div>
    </section>

    <!-- Privacy Policy Content -->
    <section class="privacy_policy section-padding">
        <div class="container">
            <div class="section-header text-center">
                <h2>Privacy Policy</h2>
            </div>

            <p>
                Welcome to Car2Go's Privacy Policy. Your privacy is important to us, and we are committed to protecting your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your data when you visit our website or use our services.
            </p>

            <h3>Information We Collect</h3>
            <p>
                We may collect personal information such as your name, contact details, and payment information when you use our services. We also collect non-personal information related to your use of our website and services for analytics and improvements.
            </p>

            <h3>How We Use Your Information</h3>
            <p>
                We use your information to provide and improve our services, process payments, and communicate with you. Your data may also be used for legal and safety purposes.
            </p>

            <h3>Protecting Your Information</h3>
            <p>
                We take measures to protect your data and ensure its security. However, no method of transmission or storage is completely secure, and we cannot guarantee absolute security.
            </p>

            <h3>Changes to Our Privacy Policy</h3>
            <p>
                We may update this Privacy Policy as our practices and services evolve. Any changes will be posted on this page.
            </p>

            <h3>Contact Us</h3>
            <p>
                If you have questions or concerns about our Privacy Policy, please contact us at car2go@gmail.com.
            </p>
        </div>
    </section>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>

    <!-- Rest of the code goes here -->
</body>
</html>
