<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Car2Go | Page details</title>
    <!--Bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
    <!--Custome Style -->
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">
    <!--OWL Carousel slider-->
    <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
    <link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
    <!--slick-slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!--bootstrap-slider -->
    <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
    <!--FontAwesome Font Style -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">

    <!-- SWITCHER -->
    <link rel="stylesheet" id="switcher-css" type="text/css" href="assets/switcher/css/switcher.css" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/red.css" title="red" media="all" data-default-color="true" />
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/orange.css" title="orange" media="all">
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/blue.css" title="blue" media="all">
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/pink.css" title="pink" media="all">
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/green.css" title="green" media="all">
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/purple.css" title="purple" media="all">

    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon-icon/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon-icon/apple-touch-icon-114-precomposed.html">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon-icon/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/images/favicon-icon/apple-touch-icon-57-precomposed.png">
    <link rel="shortcut icon" href="assets/images/favicon-icon/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">

<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Car2Go | Why Choose Us</title>
    <!-- Add your CSS links for styling here -->
    <style>
        /* General styling */
        body {
            font-family: Arial, sans-serif;
        }

        .page-heading h1 {
            font-size: 36px;
        }

        .coustom-breadcrumb {
            list-style: none;
            padding: 0;
        }

        .coustom-breadcrumb li {
            display: inline;
            margin: 0 10px;
        }

        .coustom-breadcrumb a {
            color: #fff;
            text-decoration: none;
        }

        .dark-overlay {
            background: rgba(0, 0, 0, 0.6);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        .why_choose_us {
            background-color: #fff;
            padding: 20px;
            margin-top: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        .why_choose_us h2 {
            font-size: 24px;
            margin-top: 20px;
        }

        .why_choose_us p {
            font-size: 18px;
            line-height: 1.6;
        }

        .why_choose_us strong {
            color: #007BFF;
        }

        .why_choose_us a {
            color: #007BFF;
            text-decoration: none;
        }

        .why_choose_us a:hover {
            text-decoration: underline;
        }

        .why_choose_us img {
            max-width: 100%;
            height: auto;
        }
        hr {
            border: 1px solid #000; /* Dark color, you can change the color code to your preference */
            margin: 20px 0; /* Adjust the margin as needed */
        }
    </style>
</head>
<body>
    <!-- Header -->
    <?php include('includes/header.php'); ?>

    <section class="page-header whychooseus_page">
        <div class="container">
            <div class="page-header_wrap">
                <div class="page-heading">
                    <h1>Why Choose Us</h1>
                </div>
                <ul class="coustom-breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li>Why Choose Us</li>
                </ul>
            </div>
        </div>
        <!-- Dark Overlay -->
        <div class="dark-overlay"></div>
    </section>

    <section class="why_choose_us section-padding">
        <div class="container">
            <div class="section-header text-center">
                <!-- Introduction -->
                <h2>Why Choose Car2Go</h2>
                <p>
                    At Car2Go, we understand that you have choices when it comes to car rental. Here are some compelling reasons why we should be your top choice.Our extensive vehicle selection is one of our greatest strengths. We understand that each journey is unique, and your choice of vehicle matters. That's why we offer a diverse fleet, ensuring you find the perfect match for your needs. Whether you're embarking on a solo adventure or traveling with family and friends, our selection caters to all.
                </p>
            </div>
            <hr>
            <hr>

            <!-- Feature 1 -->
            <div class="row">
                <div class="col-md-6">
                    <h3>Quality Vehicles</h3>
                    <p>
                        <strong>Extensive Vehicle Selection:</strong> Our diverse fleet ensures you find the perfect match for your needs.
                    </p>
                    <p>
                        <strong>Quality Assurance:</strong> Rigorous maintenance at official dealerships ensures prime condition.
                    </p>
                </div>
                <div class="col-md-6">
                    <!-- Add an image here -->
                    <img src="assets\images\7506746.jpg" alt="Vehicle Image">
                </div>
            </div>
            <hr>
            <!-- Feature 2 -->
            <div class="text-center">
                <h3>Convenience & Comfort</h3>
                <p>
                    All our cars come equipped with essential features like air conditioning, power steering, and electric windows.
                </p>
            </div>
            <hr>
            <!-- Feature 3 -->
            <div class="row">
    <div class="col-md-6">
        <h3>Customer Support</h3>
        <p>
            <strong>Assistance When You Need It:</strong> At Car2Go, we prioritize your convenience and peace of mind. Our dedicated customer support team is available 24/7 to assist you with any inquiries, issues, or emergencies during your rental.
        </p>
        <p>
            Whether you have questions about your reservation, need assistance with your vehicle, or encounter unexpected situations while on the road, our experienced and friendly support team is just a phone call away. We're committed to ensuring that your journey is hassle-free and that you always have the assistance you need, no matter the time or place.
        </p>
        <p>
            Your safety and satisfaction are our top priorities, and our customer support representatives are here to provide you with the guidance and solutions you require. We understand that travel plans can change, and unforeseen circumstances can arise, and that's why we offer reliable and responsive support to make your experience with Car2Go as smooth as possible.
        </p>
    </div>
                <div class="col-md-6">
                    <!-- Add an image here -->
                    <img src="assets\images\8867909.jpg" alt="Automatic Transmission Image">
                </div>
            </div>  
        </div>
    </section>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>
</body>
</html>
