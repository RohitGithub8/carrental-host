<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Car2Go | Page details</title>
    <!--Bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
    <!--Custome Style -->
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">
    <!--OWL Carousel slider-->
    <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
    <link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
    <!--slick-slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!--bootstrap-slider -->
    <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
    <!--FontAwesome Font Style -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">

    <!-- SWITCHER -->
    <link rel="stylesheet" id="switcher-css" type="text/css" href="assets/switcher/css/switcher.css" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/red.css" title="red" media="all" data-default-color="true" />
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/orange.css" title="orange" media="all">
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/blue.css" title="blue" media="all">
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/pink.css" title="pink" media="all">
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/green.css" title="green" media="all">
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/purple.css" title="purple" media="all">

    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon-icon/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon-icon/apple-touch-icon-114-precomposed.html">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon-icon/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/images/favicon-icon/apple-touch-icon-57-precomposed.png">
    <link rel="shortcut icon" href="assets/images/favicon-icon/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
    
    <!-- Custom CSS for header and footer -->
    <style>
        /* Add your custom CSS for header and footer here */
    </style>
    
    <!-- Custom CSS for About Us section -->
    <style>
        /* General styling */
        body {
            font-family: Arial, sans-serif;
        }

        .page-heading h1 {
            font-size: 36px;
        }

        .coustom-breadcrumb {
            list-style: none;
            padding: 0;
        }

        .coustom-breadcrumb li {
            display: inline;
            margin: 0 10px;
        }

        .coustom-breadcrumb a {
            color: #fff;
            text-decoration: none;
        }

        .dark-overlay {
            background: rgba(0, 0, 0, 0.6);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        .about_us {
            background-color: #fff;
            padding: 20px;
            margin-top: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        .about_us h2 {
            font-size: 24px;
            margin-top: 20px;
        }

        .about_us p {
            font-size: 18px;
            line-height: 1.6;
        }

        .about_us strong {
            color: #007BFF;
        }

        .about_us a {
            color: #007BFF;
            text-decoration: none;
        }

        .about_us a:hover {
            text-decoration: underline;
        }

        .about_us img {
            max-width: 100%;
            height: auto;
        }
        hr {
            border: 1px solid #000; /* Dark color, you can change the color code to your preference */
            margin: 20px 0; /* Adjust the margin as needed */
        }
    </style>
</head>
<body>
    <!-- Header -->
    <?php include('includes/header.php'); ?>

    <section class="page-header aboutus_page">
        <div class="container">
            <div class="page-header_wrap">
                <div class="page-heading">
                    <h1>About Us</h1>
                </div>
                <ul class="coustom-breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li>About Us</li>
                </ul>
            </div>
        </div>
        <!-- Dark Overlay -->
        <div class="dark-overlay"></div>
    </section>

    <section class="about_us section-padding">
        <div class="container">
            <div class="section-header text-center">
                <!-- Company Overview -->
                <h2>Company Overview</h2>
                <p>
                    At Car2Go, we are more than just a car rental platform; we are your trusted companions in the world of travel. Our commitment to exceptional service sets us apart. We believe that your journey should be memorable, and we're here to make that happen.
                </p>
            </div>
            <hr>

            <!-- Our Strengths -->
            <div class="row">
                <div class="col-md-6">
                    <h3>Our Strengths</h3>
                    <p>
                        <strong>Extensive Vehicle Selection:</strong> Your journey is unique, and your choice of vehicle matters. That's why we offer a diverse fleet, ensuring you find the perfect match for your needs.
                    </p>
                    <p>
                        <strong>Quality Assurance:</strong> Safety and performance are non-negotiable. Every vehicle in our fleet undergoes rigorous maintenance, ensuring it's in prime condition.
                    </p>
                    <p>
                        <strong>Convenience:</strong> All our cars come equipped with essential features like air conditioning, power steering, and electric windows. Your comfort is our priority.
                    </p>
                </div>
                <div class="col-md-6">
                    <!-- Add an image here -->
                    <img src="assets\images\7197355.jpg" alt="Vehicle Image">
                </div>
            </div>
              <hr>
            <!-- Exceptional Service -->
            <div class="text-center">
                <h3>Exceptional Service</h3>
                <p>
                    We don't just aim to meet your expectations; we strive to exceed them. Our team is committed to making your rental experience seamless and stress-free. Your time is valuable, and we work tirelessly to ensure a quick and efficient rental process.
                </p>
            </div>
            <hr>
            <!-- Social Responsibility -->
            <div class="row">
                <div class="col-md-6">
                    <h3>Social Responsibility</h3>
                    <p>
                        Car2Go is not just about business; it's about giving back and being socially responsible. By choosing Car2Go, you're supporting a company that cares about the world we live in.
                    </p>
                </div>
                <div class="col-md-6">
                    <!-- Add an image here -->
                    <img src="assets\images\Social-responsibility.png" alt="Social Responsibility Image">
                </div>
            </div>
<hr>
            <!-- Conclusion -->
            <div class="text-center">
                <h3>Experience the Difference</h3>
                <p>
                    Car2Go is your go-to destination for car rentals, offering a range of vehicles, unwavering quality, convenience, and exceptional service. When you choose Car2Go, you're not just renting a car; you're choosing a partner in travel committed to making your journey unforgettable.
                </p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>
</body>
</html>